import type { SelectedItem } from "@/types/pdf";

export const calculateUnitValue = (item: SelectedItem): number => {
  return item.preco || 0;
};

export const generateProductDescription = (item: SelectedItem): string => {
  return `${item.nome} - ${item.descricao || "Produto"}`;
};

export const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value);
};

export const getCurrentDate = (): string => {
  return new Date().toLocaleDateString("pt-BR");
};

export const calculateTotals = (
  items: SelectedItem[],
  desconto: number,
  frete: number
) => {
  const subtotal = items.reduce((acc, item) => {
    return acc + item.preco * item.quantidade;
  }, 0);

  const descontoAplicado = (subtotal * desconto) / 100;
  const totalFinal = subtotal - descontoAplicado + frete;

  return {
    subtotal,
    descontoAplicado,
    totalFinal,
  };
};
