import jwt from "jsonwebtoken";

export interface JwtPayload {
  userID: number;
  name: string;
  email: string;
  role: string;
}
const JWT_SECRET = process.env.JWT_SECRET!;
if (!JWT_SECRET) throw new Error("JWT_SECRET não definido no .env.local");

export function generateToken(payload: JwtPayload): string {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    throw new Error("JWT_SECRET não está configurado no .env.local");
  }

  return jwt.sign(payload, secret, { expiresIn: "1h" });
}
