"use client";

import type React from "react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import type { GerarPdfProps } from "@/types/pdf";
import { usePdfGenerator } from "@/hooks/use-pdf-generator";
import { Mail, Download, Loader2 } from "lucide-react";

const GerarPdfApenas: React.FC<GerarPdfProps> = ({
  itensSelecionados,
  clienteInfo,
  desconto,
  frete = 0,
  orcamentoId,
}) => {
  const [email, setEmail] = useState("");
  const [isEmailDialogOpen, setIsEmailDialogOpen] = useState(false);

  const { isGenerating, generatePdf, sendPdfByEmail } = usePdfGenerator({
    itensSelecionados,
    clienteInfo,
    desconto,
    frete,
    orcamentoId,
  });

  const handleGeneratePdf = async () => {
    try {
      await generatePdf();
    } catch (error) {
      console.error("Erro ao gerar PDF:", error);
    }
  };

  const handleSendEmail = async () => {
    if (!email.trim()) return;

    try {
      await sendPdfByEmail(email);
      setIsEmailDialogOpen(false);
      setEmail("");
    } catch (error) {
      console.error("Erro ao enviar email:", error);
    }
  };

  const LoadingSpinner = () => <Loader2 className="h-4 w-4 animate-spin" />;

  return (
    <div className="flex flex-col sm:flex-row gap-3">
      <div className="flex gap-3">
        <Button
          onClick={handleGeneratePdf}
          disabled={isGenerating || itensSelecionados.length === 0}
          className="flex items-center gap-2"
          variant="default"
        >
          {isGenerating ? <LoadingSpinner /> : <Download className="h-4 w-4" />}
          {isGenerating ? "Gerando..." : "Gerar PDF"}
        </Button>

        <Dialog open={isEmailDialogOpen} onOpenChange={setIsEmailDialogOpen}>
          <DialogTrigger asChild>
            <Button
              disabled={isGenerating || itensSelecionados.length === 0}
              variant="outline"
              className="flex items-center gap-2 bg-white/70"
            >
              <Mail className="h-4 w-4" />
              Enviar por Email
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Enviar Orçamento por Email</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="email">Email do destinatário</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="cliente@exemplo.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="mt-1"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => setIsEmailDialogOpen(false)}
                  disabled={isGenerating}
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleSendEmail}
                  disabled={isGenerating || !email.trim()}
                  className="flex items-center gap-2"
                >
                  {isGenerating ? (
                    <LoadingSpinner />
                  ) : (
                    <Mail className="h-4 w-4" />
                  )}
                  {isGenerating ? "Enviando..." : "Enviar"}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

export default GerarPdfApenas;
